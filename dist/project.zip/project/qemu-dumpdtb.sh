qemu-system-riscv64 -nographic -machine virt,dumpdtb=virt.dtb -m 256M -kernel rtthread.bin
