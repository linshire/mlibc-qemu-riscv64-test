/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-01     Jesven      The first version
 */

#ifndef  __PAGE_H__
#define  __PAGE_H__

#include <mm_page.h>
#endif  /*__PAGE_H__*/

